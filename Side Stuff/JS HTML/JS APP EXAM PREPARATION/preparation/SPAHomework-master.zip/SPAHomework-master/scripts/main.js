require(["app"], function(){
	
})