(function () {
  describe('Testing testing', function () {
    describe('nesting those suckers', function () {
      it('when empty array, expect to return 0', function () {
        var actual = 0;
        var expected = 0;
        expect(actual).to.equal(expected);
      })
    });
  });

}());