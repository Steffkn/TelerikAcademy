﻿require(["app"], function () {
    // just entry point
})