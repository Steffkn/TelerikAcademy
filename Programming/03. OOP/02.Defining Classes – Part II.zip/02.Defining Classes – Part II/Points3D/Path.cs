﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Space3D
{
    // Class Path that holds a sequence of points in the 3D space. 
    public class Path
    {
        List<IPoint3D> path = new List<IPoint3D>();
    }
}
