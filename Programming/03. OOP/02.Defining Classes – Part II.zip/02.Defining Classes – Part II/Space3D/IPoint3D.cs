﻿using System;

namespace Space3D
{
    interface IPoint3D
    {

        // property to return the point's x,y,z.
        int PointX
        {
            get;
        }
        int PointY
        {
            get;
        }
        int PointZ
        {
            get;
        }
    }
}
