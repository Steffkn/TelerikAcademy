﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Space3D;

namespace WorkingWithPoint3D
{
    class PointsTest
    {
        /*static void Main()
        {
            Point3D a = new Point3D(0, 0, 0);
            Point3D b = new Point3D(1, 1, 1);
            Console.WriteLine(a.ToString());
            Console.WriteLine(b.ToString());
            Point3D zero = Point3D.Point0;
            Console.WriteLine(zero.ToString());

            Console.WriteLine(DistanceBetweenTwoPoints.Distance(a, new Point3D(1, 1, 0)));  // kub sys strana 1 edinica, vzimame 2 sre6tupolojni vyrha na 1 ot stranite
            Console.WriteLine(Math.Sqrt(2));                                                // diagonal na kvadrat sys strana 1 edinica
            
            Console.WriteLine(DistanceBetweenTwoPoints.Distance(a, b));                     // kub sys strana 1 edinica, vzimame 2 sre6tupolojni ygyla
            Console.WriteLine(Math.Sqrt(3));                                                // razstoqnieto mejdu 2 sre6tupolojni vyrha na kuba e koren ot 3) 
            
            
        }*/
    }
}
