﻿namespace _0._2PrototypePattern
{
    public abstract class Prototype
    {
        // normal implementation
        public abstract Prototype Clone();
    }
}
